const form = document.querySelector('form');
const notesList = document.querySelector('#notes');
const pendingTasks = document.querySelector('.pendingTasks');
const toggleButton = document.getElementById('toggle-all')
const clearButton = document.getElementById('clear-storage');
const clearCompletedTasksButton = document.getElementById('clear-all-completed');
const viewAll = document.getElementById('view-all');
const viewActive = document.getElementById('view-active');
const viewCompleted = document.getElementById('view-completed');
const linkCompleted = document.querySelector('.fragcompleted');
const linkActive = document.querySelector('.fragactive');
let idCounter = 0;
let listOfNotes = [];
let completedTasks = [];
let activeTasks = [];

readLocalStorage();
drawToDo(listOfNotes);

linkActive.hashchange = event => {
    console.log("Hashchange active");
}

linkCompleted.hashchange = event => {
    console.log("Hashchange completed");
}

window.addEventListener('hashchange', function() {
    console.log(location.hash);
    if (location.hash == "#/active") {
        activeTasks = listOfNotes.filter((item) => item.noteCompleted == false);
        drawToDo(activeTasks);
    }
    else if (location.hash == "#/completed" ){
        completedTasks = listOfNotes.filter((item) => item.noteCompleted == true);
        drawToDo(completedTasks);
    }
    else {
        drawToDo(listOfNotes);
    }
  }, false);

function drawToDo(view){
    
    notesList.replaceChildren();
    
    view.forEach(item => {
        
        const li = document.createElement('li');
        const label = document.createElement('label');

        notesList.append(li);
        li.append(label);

        label.textContent = item.noteText + ' (' + item.noteOrder + ', ' + item.noteId + ', ' + item.noteCompleted + ')';
    
        const completeCheckBox = document.createElement('input');
        completeCheckBox.type = 'checkbox';
        completeCheckBox.name = item.noteId;

        if(item.noteCompleted == true){
            completeCheckBox.checked=true;
        }

        completeCheckBox.onclick = event => {

            //completedItem gets the object that corresponds to the todoNote who's checkbox was clicked
            completedItem = view.filter(n => n.noteId == completeCheckBox.name)[0];
            //flips noteCompleteds value (true or false)
            completedItem.noteCompleted = !completedItem.noteCompleted;

            renderActiveTasksCount();
            writeLocalStorage();
            drawToDo(view);
        }

        toggleButton.onclick = event => {
            
            const atLeastOneActive = listOfNotes.some(note => !note.noteCompleted);

            if (atLeastOneActive) {

                listOfNotes.forEach(turnFalseTrue => {
                    turnFalseTrue.noteCompleted = true;
                })
                console.log(listOfNotes);
            }
            else{
                listOfNotes.forEach(turnTrueFalse => {
                    turnTrueFalse.noteCompleted = false;
                })
                console.log(listOfNotes);
            }
            
            renderActiveTasksCount();
            writeLocalStorage();
            drawToDo(view);
        }
        
        li.prepend(completeCheckBox);

        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.name = item.noteId;
        removeButton.value = item.noteOrder;
        removeButton.className = 'remove-button'
        removeButton.textContent = '❌';

        removeButton.onclick = event => {

            //removes the button that corresponds to that particular button value
            listOfNotes.splice(parseInt(removeButton.value), 1);

            //loops through the remaining objects in listOfNotes and giving the new order values
            for (let i=0; i<listOfNotes.length; i++){
                listOfNotes[i].noteOrder = i;
            }

            writeLocalStorage()
            localStorage.removeItem(removeButton.name);
            drawToDo(view);
            console.log(listOfNotes);
            renderActiveTasksCount();
        };
        
        li.append(removeButton);
    })

};

function writeLocalStorage(){

    listOfNotes.forEach(item => {
        localStorage.setItem(item.noteId, JSON.stringify(item))
    })

    let noteIdStorage = listOfNotes.map(n => n.noteId);
    localStorage.setItem('todo-keys', JSON.stringify(noteIdStorage));

}

function readLocalStorage(){

    let noteIdStorage = JSON.parse(localStorage.getItem('todo-keys'));

    if(noteIdStorage==null || noteIdStorage.length==0){
        listOfNotes = [];
    }
    else{
        listOfNotes = noteIdStorage.map(n => JSON.parse(localStorage.getItem(n)));
        idCounter = noteIdStorage.pop() + 1;
    }
}

form.onsubmit = event => {
    event.preventDefault();

    const textInput = form.elements.note.value;
    //event.reset;
    let itemOrder = listOfNotes.length;

    let todoNote = {
        noteText: textInput, 
        noteId: idCounter,
        noteCompleted: false,
        noteOrder: itemOrder
    };

    listOfNotes.push(todoNote);

    writeLocalStorage()
    drawToDo(listOfNotes);

    idCounter++;

    console.log(listOfNotes);
    console.log(itemOrder);
    renderActiveTasksCount();
};

clearButton.onclick = event => {
    localStorage.clear();
};

function renderActiveTasksCount(){
    activeTasksCount = 0;
    for (let i=0; i < listOfNotes.length; i++){
        
        if(!listOfNotes[i].noteCompleted){
            activeTasksCount++;
        }
    }

    if(activeTasksCount === 1){
        pendingTasks.textContent = activeTasksCount + ' item left';
    }
    else{
        pendingTasks.textContent = activeTasksCount + ' items left';
    }
};

clearCompletedTasksButton.onclick = event => {
    let deletedNotes = listOfNotes.filter((item) => item.noteCompleted == true);
    listOfNotes = listOfNotes.filter((item) => item.noteCompleted == false);

    deletedNotes.forEach(item => {
        localStorage.removeItem(item.noteId);
    })

    drawToDo(listOfNotes);
    writeLocalStorage();
};

viewAll.onclick = event => {
    drawToDo(listOfNotes);
};

viewActive.onclick = event => {
    activeTasks = listOfNotes.filter((item) => item.noteCompleted == false);
    drawToDo(activeTasks);
};

viewCompleted.onclick = event => {
    completedTasks = listOfNotes.filter((item) => item.noteCompleted == true);
    drawToDo(completedTasks);
};

  
            